expect_true(TestUseTry::fun())
