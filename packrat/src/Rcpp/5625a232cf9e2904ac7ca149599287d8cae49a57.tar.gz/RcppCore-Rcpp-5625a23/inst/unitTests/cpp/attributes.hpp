
#ifndef __RCPP_UNITTESTS_ATTRIBUTES__
#define __RCPP_UNITTESTS_ATTRIBUTES__

/*
 *  dummy header used to test that local includes for sourceCpp are working
 */

#endif // __RCPP_UNITTESTS_ATTRIBUTES__
