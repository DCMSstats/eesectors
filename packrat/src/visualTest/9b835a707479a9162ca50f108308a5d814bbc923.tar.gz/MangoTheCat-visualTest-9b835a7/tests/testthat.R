library(testthat)
library(visualTest)

test_check("visualTest")
