library(testthat)
test_check("fakepackage")
