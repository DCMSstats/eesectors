These are hooks I found useful for working on `r-travis`; symlink them into
`$REPO_ROOT/.git/hooks` to use them.
