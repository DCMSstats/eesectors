library(testthat)
test_package("fakepackage")
