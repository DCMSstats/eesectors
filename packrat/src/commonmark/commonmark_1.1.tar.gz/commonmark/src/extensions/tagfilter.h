#ifndef TAGFILTER_H
#define TAGFILTER_H

#include "core-extensions.h"

cmark_syntax_extension *create_tagfilter_extension(void);

#endif
