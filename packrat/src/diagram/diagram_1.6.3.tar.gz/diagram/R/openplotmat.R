
##==============================================================================
# openplotmat: opens a plot, ready to plot diagrams or transition matrices
##==============================================================================

openplotmat <- function(asp=NA,...)
  emptyplot(asp=asp, ...)

