library(testthat)
library(fontquiver)

test_check("fontquiver")
