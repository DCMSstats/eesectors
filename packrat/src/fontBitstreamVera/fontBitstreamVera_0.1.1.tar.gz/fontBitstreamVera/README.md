
# fontBitstreamVera

This package is a placeholder for the Bitstream Vera font. It is
intended for the `fontquiver` package.

This font lives in its own package because CRAN regulations require
package contents to be covered by at most one licence.
